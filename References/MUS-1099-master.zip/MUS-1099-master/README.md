# MUS-1099
ISA sound card based on the SAA1099 sound generator

This card is based on the work by Sergey and Tronix of the Vintage Computer Federation forums and is an attempt at 
creating a working clone of the Creative CMS / Game Blaster ISA cards.

More information can be found at http://www.vcfed.org/forum/showthread.php?59846-Creative-Music-System-Game-Blaster-clone
